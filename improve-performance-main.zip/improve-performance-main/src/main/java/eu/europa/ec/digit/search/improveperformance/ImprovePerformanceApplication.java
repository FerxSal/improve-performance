package eu.europa.ec.digit.search.improveperformance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ImprovePerformanceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImprovePerformanceApplication.class, args);
	}

}
