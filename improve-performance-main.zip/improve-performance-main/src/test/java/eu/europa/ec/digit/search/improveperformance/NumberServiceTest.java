package eu.europa.ec.digit.search.improveperformance;

import static java.util.Arrays.asList;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.nullValue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.integration.IntegrationAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@SpringBootTest
class NumberServiceTest {

    Logger log = org.slf4j.LoggerFactory.getLogger(NumberServiceTest.class);
    
    @Autowired
    NumberService numberService;

    @Test
    void testSpeed() {
        
        List<Integer> data = numberService.generateData();
        
        long start  = System.currentTimeMillis();
        Integer duplicateSlow = numberService.findSmallestDuplicate(data);
        long tookSlow = System.currentTimeMillis() - start;
        System.out.println(tookSlow);

        start = System.currentTimeMillis();
        Integer duplicateFast = numberService.findSmallestDuplicateImproved(data);
        long tookFast = System.currentTimeMillis() - start;
        System.out.println(tookFast);
        
        assertEquals(duplicateSlow, duplicateFast);
        assertTrue(tookSlow > tookFast*1000);
        log.info("slow: {}, fast: {}", tookSlow, tookFast);
        
        
    }
    
    @Test
    void testNull() { 
        
        List<Integer> data = asList(1, 2, 3);
        
        Integer result = numberService.findSmallestDuplicate(data);
        assertNull(result);
        
        result = numberService.findSmallestDuplicateImproved(data);
        assertNull(result);

    }


    @Test
    void testDuplicate(){

        List<Integer> data = asList(5,3,4,1,3,7,2,9,9,4);
        Integer result = numberService.findSmallestDuplicateImproved(data);
        assertEquals(3,result);

    }

}
